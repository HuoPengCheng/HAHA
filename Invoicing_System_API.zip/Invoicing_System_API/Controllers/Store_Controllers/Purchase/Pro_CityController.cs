﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Invoicing_System_API.Models;
using Invoicing_System_API.Models.新文件夹;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Invoicing_System_API.Controllers.Store_Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class Pro_CityController : ControllerBase
    {
        //依赖注入
        public JXCContextDb db;
        public Pro_CityController(JXCContextDb jXC) { this.db = jXC; }
        [HttpGet("GetPro")]
        public async Task<IEnumerable<Pro>> GetPro()
        {
            return await db.Pro.ToListAsync();
        }
        [HttpGet("GetCity")]
        public async Task<IEnumerable<City>> GetCity(int pid)
        {
            return await db.City.Where(x=>x.Pid==pid).ToListAsync();
        }
    }
}
