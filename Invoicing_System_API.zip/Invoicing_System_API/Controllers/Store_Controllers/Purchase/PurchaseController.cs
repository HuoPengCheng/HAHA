﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;
using Invoicing_System_API.Models;
using Invoicing_System_API.Models.Sale_Model;
using Invoicing_System_API.Models.Store_Model;
using Invoicing_System_API.Models.Store_Model.Pruchase;
using Invoicing_System_API.Models.新文件夹;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace Invoicing_System_API.Controllers.Store_Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PurchaseController : ControllerBase
    {
        //创建连接
        public static string ConnStr = "Data Source=10.3.194.55;Initial Catalog=PSS;Integrated Security=True";
        public JXCContextDb db;
        public PurchaseController(JXCContextDb jXC) { this.db = jXC; }
        //显示采购信息
        [HttpGet("GetAll")]
        public DataPage GetAll(int CId,int PId,int State,string sName = "", int pageIndex = 1, int pageSize = 8)
        {


            var list = from p in db.PurchaseRequisition
                       from a in db.accept_Goods
                       from pr in db.PurchaseInfoRequest
                       from s in db.StoreInfos
                       from c in db.City
                       from ps in db.Pro
                       where p.PRId == a.Proid && a.AId == pr.Proid && s.SId == p.StoreId&&c.Pid==ps.PId&&c.CId==s.CityId&&ps.PId==s.ProId
                       select new PruchaseAllList { Address = s.Address, Capacity = s.Capacity, CName = c.CName, PName = ps.PName, ProName = p.ProName, ProNum = p.ProNum, SName = s.SName, PRId = p.PRId, PState = p.PState, PId = ps.PId, CId = c.CId,CreateTime=pr.CreateTime.ToString("yyyy-mm-dd"),SinglePrice=pr.SinglePrice,Supplier=pr.Supplier,TotalPrice=pr.TotalPrice};
            //仓库名称查询
            if (sName != null && sName != "--全部--")
            {
                list = list.Where(x => x.SName.Contains(sName)) ;
            }
            //入库状态查询
            if(State!=2)
            {
                list = list.Where(x => x.PState == State);
            }
            //省份查询
            if(PId!=0)
            {
                list = list.Where(x => x.PId == PId);
            }
            //城市查询
            if (CId != 0)
            {
                list = list.Where(x => x.CId == CId);
            }
            //实例化
            DataPage dp = new DataPage();
            dp.PruchaseAllLists = list.Skip((pageIndex - 1)*pageSize).Take(pageSize).ToList();
            //总条数
            var AllCount = list.Count();
            if (AllCount % pageSize == 0)
            {
                dp.TotalPage = AllCount / pageSize;
            }
            else
            {
                dp.TotalPage = AllCount / pageSize + 1;
            }
            return  dp;
        }
        //获取仓库下拉框
        [HttpGet("StoreBind")]
        public async Task<List<StoreInfo>> StoreBind()
        {
            var list = from s in db.StoreInfos
                       select new StoreInfo { SName = s.SName, SId = s.SId };
            return await list.ToListAsync();
        }
        //申请采购商品(同时传送商品Id)
        [HttpPost("AddPruchase")]
        public async Task<int> AddPruchase(PurchaseRequisition p)
        {
            SqlParameter[] parameters = new SqlParameter[]
           {
                new SqlParameter(){ParameterName="@proName",DbType=System.Data.DbType.String,Value=p.ProName},
                new SqlParameter(){ParameterName="@ProNum",DbType=System.Data.DbType.Int32,Value=p.ProNum},
                new SqlParameter(){ParameterName="@StoreId",DbType=System.Data.DbType.Int32,Value=p.StoreId},
           };
            //创建对象
            using (var conn = new SqlConnection(ConnStr))
            {
                //打开
                conn.Open();
                //创建命令对象
                var cmd = new SqlCommand("AddPruchase", conn);
                //告诉执行的是存储过程
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddRange(parameters);
                return await cmd.ExecuteNonQueryAsync();
            }

        }
        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpDelete("DelPruchase")]
        public async Task<int> DelPruchase(int Id)
        {
            var Data = db.PurchaseRequisition.Find(Id);
            db.Remove(Data);
            return await db.SaveChangesAsync();
        }
        /// <summary>
        /// 修改（通过修改状态来休息sql仓库存量）
        /// </summary>
        /// <param name="UpId"></param>
        /// <returns></returns>
        [HttpPut("UptState_Capacity")]
        public async Task<int> UptState_Capacity(int UpId )
        {
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter(){ParameterName="@UpId",DbType=System.Data.DbType.Int32,Value=UpId}
            };
            //创建对象
            using (var conn=new SqlConnection(ConnStr))
            {
                //打开
                conn.Open();
                //创建命令对象
                var cmd = new SqlCommand("UptState_Capacity", conn);
                //告诉执行的是存储过程
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddRange(parameters);
                var i = await cmd.ExecuteNonQueryAsync();
                return i;
            }
        }
        [HttpGet("OutStoreBill")]

        public async Task<ActionResult<OutStoreBill>> GetStoreBill(int oid=0)
        {
            var list = db.outStoreBills.Where(x => x.OId.Equals(oid));
            return await list.FirstOrDefaultAsync();
        }
        /// <summary>
        /// 采购单
        /// </summary>
        /// <returns></returns> 
        [HttpGet("GetPruchaseinfo")]
        public PageViewModel Getlist(string proName, string LSupplier, int state = -1, int pageIndex = 1, int pageSize = 8)
        {
            var list = db.PurchaseInfo.ToList();
            //根据商品名称查询
            if (proName != null)
            {
                list = db.PurchaseInfo.Where(x => x.ProName.Contains(proName)).ToList();


            }
            //根据供货商查询
            else if (LSupplier != null)


            {
                list = db.PurchaseInfo.Where(x => x.LSupplier.Contains(LSupplier)).ToList();
            }
            //查询状态
            else if (state!=-1)
            {
                list = db.PurchaseInfo.Where(x => x.LState == state).ToList();
            }
            


            else
            {
                list = db.PurchaseInfo.ToList();


            }

            var count = list.Count();
            int page;
            if (pageIndex < 1)
            {
                pageIndex = 1;
            }
            if (count % pageSize == 0)
            {
                page = count / pageSize;
            }
            else
            {
                page = count / pageSize + 1;
            }
            if (pageIndex > page)
            {
                pageIndex = page;
            }
            var p = new PageViewModel();
            p.PurchaseInfoS = list.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
            p.pageIndex = pageIndex;//当前页
            p.PageTotal = page;//总页数
            return p;


        }


        //选择仓库,并且入库
        [HttpPost("add_Pruchaseinfo_Store")]
        public async Task<int> add_Pruchaseinfo_Store(string storeid, string proid )
        {
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter(){ParameterName="@storeid",DbType=System.Data.DbType.Int32,Value=storeid},
                new SqlParameter(){ParameterName="@proid",DbType=System.Data.DbType.Int32,Value=proid}
            };
            //创建对象
            using (var conn = new SqlConnection(ConnStr))
            {
                //打开
                conn.Open();
                //创建命令对象
                var cmd = new SqlCommand("Add_pruchaseOderIds", conn);
                //告诉执行的是存储过程
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddRange(parameters);
                var i = await cmd.ExecuteNonQueryAsync();
                return i;
            }
        }



    }
}
