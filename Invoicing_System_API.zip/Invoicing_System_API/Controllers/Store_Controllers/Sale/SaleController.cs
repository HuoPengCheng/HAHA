﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Invoicing_System_API.Models;
using Invoicing_System_API.Models.Sale_Model;
using Invoicing_System_API.Models.Store_Model.Sale;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Invoicing_System_API.Controllers.Store_Controllers.Sale
{
    [Route("api/[controller]")]
    [ApiController]
    public class SaleController : ControllerBase
    {
        //依赖注入
        public JXCContextDb db;
        public SaleController(JXCContextDb jXC) { this.db = jXC; }
        //显示出库单列表
        [HttpGet("GetOutSaleList")]
        public OutSaleDataPage GetOutSaleList(int pageIndex=1,int pageSize=8)
        {
            
            var data =  from s in db.outStoreBills select s;
            //实例化
            OutSaleDataPage dp = new OutSaleDataPage();
            dp.list = data.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
            //总条数
            var AllCount = data.Count();
            if (AllCount % pageSize == 0)
            {
                dp.TotalPage = AllCount / pageSize;
            }
            else
            {
                dp.TotalPage = AllCount / pageSize + 1;
            }
            return dp;
        }
    }
}