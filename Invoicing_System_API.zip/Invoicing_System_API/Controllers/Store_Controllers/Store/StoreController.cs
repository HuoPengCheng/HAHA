﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Invoicing_System_API.Models;
using Invoicing_System_API.Models.Store_Model;
using Invoicing_System_API.Models.Store_Model.Pruchase;
using Invoicing_System_API.Models.Store_Model.Store;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace Invoicing_System_API.Controllers.Store_Controllers.Store
{
    [Route("api/[controller]")]
    [ApiController]
    public class StoreController : ControllerBase
    {
        //依赖注入
        public JXCContextDb db;
        public StoreController(JXCContextDb jXC) { this.db = jXC; }
        /// <summary>
        /// 显示仓库列表
        /// </summary>
        /// <returns></returns>
        [HttpGet("GetStoreList")]
        public DataPage2 GetStoreList(string name="", int pageIndex = 1, int pageSize = 8)
        {
            var list = from s in db.StoreInfos
                       from sg in db.storeGoods
                       where s.SId == sg.StoreId
                       select new StoreAllData { Capacity = s.Capacity, ProName = sg.ProName, SName = s.SName, ProNum = sg.ProNum };

            if(name!=null&&name!="--全部--")
            {
                list = list.Where(x => x.SName == name);
            }
            //实例化
            DataPage2 dp = new DataPage2();
            dp.storeAllDatas = list.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
            //总条数
            var AllCount = list.Count();
            if (AllCount % pageSize == 0)
            {
                dp.TotalPage = AllCount / pageSize;
            }
            else
            {
                dp.TotalPage = AllCount / pageSize + 1;
            }
            return dp;
        }
        /// <summary>
        /// 导出的数据
        /// </summary>
        /// <returns></returns>
        [HttpGet("DaoFile")]
        public async Task<IEnumerable<StoreAllData>> DaoFile()
        {
            var list= from s in db.StoreInfos
                      from sg in db.storeGoods
                      where s.SId == sg.StoreId
                      select new StoreAllData { Capacity = s.Capacity, ProName = sg.ProName, SName = s.SName, ProNum = sg.ProNum };
            return await list.ToListAsync();
        }
        /// <summary>
        /// 修改（通过修改状态来休息sql仓库存量）
        /// </summary>
        /// <param name="UpId"></param>
        /// <returns></returns>
        [HttpPut("In_OutSaleOrder")]
        public async Task<int> In_OutSaleOrder(int UpId)
        {
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter(){ParameterName="@Oid",DbType=System.Data.DbType.Int32,Value=UpId}
            };
            //创建对象
            using (var conn = new SqlConnection(Store_Controllers.PurchaseController.ConnStr))
            {
                //打开
                conn.Open();
                //创建命令对象
                var cmd = new SqlCommand("In_OutSaleOrder", conn);
                //告诉执行的是存储过程
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddRange(parameters);
                return await cmd.ExecuteNonQueryAsync();
            }
        }
    }
}
