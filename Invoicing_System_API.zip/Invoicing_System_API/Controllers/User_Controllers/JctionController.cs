﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Invoicing_System_API.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Cors;
using Store_Management_MVC.Models.User_Model;
using Invoicing_System_API.Models.User_Model;
using Invoicing_System_API.Models.User_Model.虚拟表;
using System.Data;

using Microsoft.Data.SqlClient;
using Dapper;


namespace Invoicing_System_API.Controllers.User_Controllers
{
    [Produces("application/json", "application/xml")]
    [Route("api/[controller]")]
    [EnableCors("cors")]//设置跨域处理的代理
    [ApiController]



    public class JctionController : ControllerBase
    {
        public JXCContextDb db;
        public JctionController(JXCContextDb db) { this.db = db; }

        private string con = "Data Source=.;Initial Catalog=PRE;Integrated Security=true";

        #region 管理权限
        [Route("RoleLogin")]
        [HttpGet]
        public async Task<IEnumerable<Role>> Show(string name) 
        {
            var list = from a in db.userInfos//用户表
                       from b in db.urs//用户角色表
                       from c in db.roleInfos//角色表
                       where a.UId== b.UId && b.RId == c.RId&& a.UserName == name
                       select new Role { RId = b.RId, RName = c.RName };

            return await list.ToListAsync();

        }


        [Route("S")]
        [HttpGet]
        public List<Juers> RoleJue(string name = "")  //父级菜单 C#
        {
            using (IDbConnection a = new SqlConnection(con))
            {
                //userInfos 用户表   roleInfos角色表  urs用户角色表
                string sql = $"select c.RId from userInfos a join  urs b on a.UId =b.UId join  roleInfos c on b.RId = c.RId where a.UserName = '{name}'";  //根据用户名获取数据
                var list = a.Query<RoleInfos>(sql).FirstOrDefault(); 
                int id = list.RId;//查出的角色id    Rjs角色菜单表   juers菜单表  roleInfos角色表
                string str = $"select  juers.JID,juers.Menu,Juers.MenuUrl from roleinfos join rjs on roleinfos.RID=rjs.RID join juers on rjs.JID = juers.JID where roleinfos.RID='{id}' and FID=0";//根据ID查询权限
                return a.Query<Juers>(str).ToList();
            }
        }

        [Route("Two")]
        [HttpGet]
        public List<Juers> EnumTwo(int id)  //二级菜单
        {
            using (IDbConnection a = new SqlConnection(con))
            {
                string sql = $"select * from juers where FId='{id}'";
                return a.Query<Juers>(sql).ToList();

            }


        }

        [Route("TwoDian")]   
        [HttpGet]
        public List<Juers> Dian(int id)
        {
            int Pid = 0;
            using (IDbConnection a = new SqlConnection(con))
            {
                //roleInfos角色表     Rjs角色菜单表   juers菜单表  
                string sql = $"select d.JID,d.Menu,d.FID,d.MenuUrl from roleinfos b  join rjs c on b.RID=c.RID join juers d on c.JID=d.JID where 1=1 ";
                sql += $" and b.RID='{id}'and d.FID='{Pid}'";
                return a.Query<Juers>(sql).ToList();

            }
        }
        #endregion

    }
}
