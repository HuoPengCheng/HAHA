﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using Store_Management_MVC.Models.User_Model;
using Invoicing_System_API.Models;
using Store_Management_MVC.Models;
using Microsoft.EntityFrameworkCore;
using Invoicing_System_API.Models.User_Model.虚拟表;

namespace Invoicing_System_API.Controllers.User_Controllers
{
    [Produces("application/json", "application/xml")]
    [Route("api/[controller]")]
    [EnableCors("cors")]//设置跨域处理的代理
    [ApiController]
    public class SelectController : ControllerBase
    {
        public JXCContextDb db;
        public SelectController(JXCContextDb db) { this.db = db; }  //依赖注入


        #region 单位部门
         [HttpGet("Xiala")]
        public async Task<IEnumerable<Depart>> Bang() //部门下拉框
        {

            
            var list = from s in db.departments
            select new Depart { DName = s.DName , DId = s.DId};
            return await list.ToListAsync();
        }

        [HttpGet("AddDepar")]
        public async Task<ActionResult<int>> AddSelect(string Department)  //部门添加
        {
            Department a = new Department();
            a.DName = Department;
            db.departments.Add(a);
            return await db.SaveChangesAsync();

        }
        #endregion


        #region 用户管理
        [HttpGet("JiaoSe")]
        public async Task<IEnumerable<Role>> JiaoSe() //(用户管理)角色下拉框
        {


            var list = from s in db.roleInfos
                       select new Role { RName = s.RName, RId = s.RId };
            return await list.ToListAsync();
        }
        #endregion
       

    }
}
   