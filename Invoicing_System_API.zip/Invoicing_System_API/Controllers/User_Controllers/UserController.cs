﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Invoicing_System_API.Models;
using Store_Management_MVC.Models.User_Model;
using Microsoft.EntityFrameworkCore;
using Invoicing_System_API.Models.User_Model;
using System;
using System.Data;

namespace Invoicing_System_API.Controllers.User_Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Produces("application/json", "application/xml")]
    [EnableCors("cors")]//设置跨域处理的代理
    public class UserController : ControllerBase
    {
        public JXCContextDb db;
        public UserController(JXCContextDb db) { this.db = db; }  //依赖注入

        LogHelper a = new LogHelper();

       


        #region 用户管理
        [Route("Jia")]
        [HttpPost]
        public async Task<ActionResult<int>> Add([FromForm] UserInfos obj)  //(用户管理)新增用户
        {
            
            
            db.userInfos.Add(obj);
            obj.UserState = 1;
            a.Log(@"d:\\log.txt", $"管理员 ，新增了用户信息账号为{obj.UserName} {DateTime.Now}");
            return await db.SaveChangesAsync();

        }

        [Route("Upt")]
        [HttpPut]
        public async Task<ActionResult<int>> Upt([FromForm] UserInfos obj)  //(用户管理)新增用户
        {
            db.userInfos.Add(obj);
            a.Log(@"d:\\log.txt", $"管理员 ，修改 了用户信息账号为{obj.UserName} {DateTime.Now}");
            return await db.SaveChangesAsync();

        }

        [HttpGet("Yuser")]
        public async Task<IEnumerable<UserX>> Yuser()  //(用户管理 )显示所有用户信息
        {

            var s = from a in db.userInfos
                    from bb in db.departments
                    from cc in db.roleInfos
                    where a.DepartId == bb.DId && a.RoleId == cc.RId
                    select new UserX
                    {
                        UId = a.UId,
                        UserName = a.UserName,
                        aa = bb.DName,
                        UserPwd = a.UserPwd,
                        RealName = a.RealName,
                        Sex = a.Sex,
                        Age = a.Age,
                        b = cc.RName,
                        TeIphone = a.TeIphone,
                        UserState = a.UserState
                    };
            return await s.ToListAsync();
        }

        [HttpPut("Upt")]

        public async Task<ActionResult<int>> UserUpt(UserInfos em) //(用户管理)编辑用户信息
        {
            db.Entry(em).State = EntityState.Modified;
            a.Log(@"d:\\log.txt", $"管理员 ，编辑了用户信息是{em} {DateTime.Now}");
            return await db.SaveChangesAsync();
        }


        [HttpGet("Fan")]
        public UserInfos Fan(int id) //(用户管理)编辑用户信息
        {
            return db.userInfos.FirstOrDefault(s => s.UId == id);
        }

        [HttpGet("UserShow")]
        #endregion

        [Route("show")]
        public async Task<IEnumerable<UserX>> show(int id)  //(部门管理) 部门查询显示
        {
           
                var  s = from a in db.userInfos
                        from bb in db.departments
                        where a.DepartId == bb.DId
                        select new UserX { UId = a.UId, UserName = a.UserName, aa = bb.DName };

            if (id!=0)
            {
                s = from a in db.userInfos
                    from bb in db.departments
                    where a.DepartId == bb.DId && a.DepartId == id
                 select new UserX { UId = a.UId, UserName = a.UserName, aa = bb.DName };
            }
            //a.Log(@"d:\\log.txt", $"管理员 ，查询了部门信息是{id} {DateTime.Now}");
            return await s.ToListAsync();
         
        } 

        [Route("Delet")]
        [HttpDelete]
        public async Task<ActionResult <int>> Del(int id) //(部门管理)清除用户
        {
          
            UserInfos a = db.userInfos.Find(id);
            db.userInfos.Remove(a);
            return await db.SaveChangesAsync();  
        }

        #region 权限冻结
        [Route("UserState")]
        [HttpGet]
        public async Task<IEnumerable<UserX>> UserState() //(更改状态显示页面)
        {
           
            var list = from a in db.userInfos
                       from b in db.departments  
                       select new UserX { UId = a.UId, UserName = a.UserName ,aa=b.DName, UserState = a.UserState };
            return await list.ToListAsync();
        }

        [Route("UptState")]
        [HttpPut]
        public async Task<ActionResult<int>> UptStat(int id) //(更改状态)
        { 
            UserInfos a = db.userInfos.Find(id);
            db.Entry(a).State = EntityState.Modified;
            if (a.UserState == 0)
            {
                a.UserState = 1;

            }
            else
            {
                a.UserState = 0;
            }
            return await db.SaveChangesAsync();
        }
        #endregion



    }
}