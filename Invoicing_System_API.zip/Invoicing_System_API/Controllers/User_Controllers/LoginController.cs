﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using Invoicing_System_API.Models;
using Microsoft.EntityFrameworkCore;

namespace Invoicing_System_API.Controllers.User_Controllers
{
    [Produces("application/json", "application/xml")]
    [Route("api/[controller]")]
    [EnableCors("cors")]//设置跨域处理的代理
    public class LoginController : Controller
    {
        public JXCContextDb db;
        public LoginController(JXCContextDb db) { this.db = db; }
        // GET: UserAddController
        


        [Route("Login")]
        [HttpGet]
        public async Task<ActionResult<int>> Login(string name, string mm)  //登录平台
        {
            
            return await db.userInfos.Where(s => s.UserName.Equals(name) && s.UserPwd.Equals(mm)).CountAsync();
        }



    }
}
