﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Controllers.User_Controllers
{
    public class LogHelper
    {
        public void Log(string path, string content)
        {
            using (TextWriter tr = new StreamWriter(path, true))
            {
                tr.WriteLine(content);
            } //(操作日志)
        }
    }
}
