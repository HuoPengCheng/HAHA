﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Invoicing_System_API.Models;
using Invoicing_System_API.Models.pruchase_Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Invoicing_System_API.Controllers.Pruchase_Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class XSController : ControllerBase
    {
        public JXCContextDb db;

        public XSController(JXCContextDb db) { this.db = db; }
        //显示
        //此方法用的linq查询   
        [HttpGet("Getlist")]
        public PageViewModel Getlist(string proName, string LSupplier, int state = -1, int pageIndex = 1, int pageSize = 4)
        {
            var list = db.PurchaseInfo.ToList();
            //根据商品名称查询
            if (proName != null)
            {
                list = db.PurchaseInfo.Where(x => x.ProName.Contains(proName)).ToList();

            }
            //根据供货商查询
            else if (LSupplier != null)

            {
                list = db.PurchaseInfo.Where(x => x.LSupplier.Contains(LSupplier)).ToList();
            }
            //查询状态
            else if (state != -1)
            {
                list = db.PurchaseInfo.Where(x => x.LState == state).ToList();
            }

            else
            {
                list = db.PurchaseInfo.ToList();

            }

            var count = list.Count();
            int page;
            if (pageIndex < 1)
            {
                pageIndex = 1;
            }
            if (count % pageSize == 0)
            {
                page = count / pageSize;
            }
            else
            {
                page = count / pageSize + 1;
            }
            if (pageIndex > page)
            {
                pageIndex = page;
            }
            var p = new PageViewModel();
            p.PurchaseInfoS = list.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
            p.pageIndex = pageIndex;//当前页
            p.PageTotal = page;//总页数
            return p;

        }
        [HttpGet("Dell")]
        //删除
        public async Task<ActionResult<int>> Dell(int id)
        {
            db.PurchaseInfo.Remove(db.PurchaseInfo.FirstOrDefault(m => m.LId == id));
            return await db.SaveChangesAsync();

        }
        [HttpGet("rk")]
        //入库
        public async Task<ActionResult<int>> rk(int id)
        {
            PurchaseInfo p = db.PurchaseInfo.Find(id);
            p.LState = 0;
            db.Entry(p).State = EntityState.Modified;
            return await db.SaveChangesAsync();

        }
        [HttpPost("ADDs")]
        //采购添加
        public async Task<ActionResult<int>> ADDs(PurchaseInfo p)
        {
            db.PurchaseInfo.Add(p);
            return await db.SaveChangesAsync();
        }
    }
}
