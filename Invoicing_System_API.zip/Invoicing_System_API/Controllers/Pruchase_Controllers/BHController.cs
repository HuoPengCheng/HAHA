﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Invoicing_System_API.Models;
using Invoicing_System_API.Models.pruchase_Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Invoicing_System_API.Controllers.Pruchase_Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BHController : ControllerBase
    {
        public JXCContextDb db;
        public BHController(JXCContextDb db) { this.db = db; }
        [HttpGet("Getlist")]
        //接受商品添加请求显示
        public PageViewModel Getlist(string proName, string lSupplier, int pageIndex = 1, int pageSize = 4)
        {

            var list = (from a in db.accept_Goods
                        join ap in db.PurchaseRequisition on a.Proid equals ap.PRId
                        select new XNjieshou
                        {
                            AId = a.AId,
                            ProName = ap.ProName,
                            ProNum = ap.ProNum,
                        }).ToList();

            //根据商品名称查询
            if (proName != null)
            {
                list = list.Where(x => x.ProName.Contains(proName)).ToList();
            }
            //根据供货商查询
            if (lSupplier != null)
            {
                list = list.Where(x => x.Supplier.Contains(lSupplier)).ToList();
            }
            else
            {
                list = list.ToList();
            }
            var count = list.Count();
            int page;
            if (pageIndex < 1)
            {
                pageIndex = 1;
            }
            if (count % pageSize == 0)
            {
                page = count / pageSize;
            }
            else
            {
                page = count / pageSize + 1;
            }
            if (pageIndex > page)
            {
                pageIndex = page;
            }
            var p = new PageViewModel();
            p.XNjieshouS = list.Skip((pageIndex - 1) * pageSize).Take(pageSize).ToList();
            p.pageIndex = pageIndex;//当前页
            p.PageTotal = page;//总页数
            return p;
        }
        //反填
        [HttpGet("Ft")]
        public XNjieshou Ft(int id)
        {
            var list = from a in db.accept_Goods
                       join ap in db.PurchaseRequisition on a.Proid equals ap.PRId
                       select new XNjieshou
                       {
                           AId = a.AId,
                           Proid=a.Proid,
                           ProName = ap.ProName,
                           ProNum = ap.ProNum,
                       };
            list = list.Where(x => x.AId.Equals(id));
            return list.FirstOrDefault();
        }
        //添加PurchaseRequisition表里的字段
        [HttpPost("dyadd")]
        public async Task<ActionResult<int>> dyadd(PurchaseInfoRequest p)
        {
            db.PurchaseInfoRequest.Add(p);
            return await db.SaveChangesAsync();
        }

    }
}
