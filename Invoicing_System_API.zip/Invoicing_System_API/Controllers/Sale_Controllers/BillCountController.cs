﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Invoicing_System_API.Models.Sale_Model;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Reflection;

namespace Invoicing_System_API.Controllers.Sale_Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BillCountController : ControllerBase
    {
        [Route("GetCount")]
        [HttpGet]
        public List<DataCount> GetCount(int status)
        {
            string sql = $"select  count(1) billcount,MONTH(CreateTime) Mon from SaleOrderInfo s join SaleListInfo o on s.SOId = o.SOId join OrdorStatus t on o.OrdorStatus = t.SId  group by MONTH(CreateTime),SId having SId={status} order by MONTH(CreateTime)";
            using (SqlConnection conn = new SqlConnection("server=10.3.194.55;database=PSS;uid=sa;pwd=123"))
            {
                using (SqlCommand cmd = new SqlCommand(sql, conn))
                {
                    DataTable dt = new DataTable();
                    SqlDataAdapter dapt = new SqlDataAdapter(cmd);
                    dapt.Fill(dt);
                    List<DataCount> list = new List<DataCount>();
                    foreach (DataRow dr in dt.Rows)
                    {
                        DataCount dc = new DataCount();
                        var ps = dc.GetType().GetProperties();
                        foreach (var p in ps)
                        {
                            p.SetValue(dc, dr[p.Name]);
                        }
                        list.Add(dc);
                    }
                    return list;
                }
            }
        }
    }
}
