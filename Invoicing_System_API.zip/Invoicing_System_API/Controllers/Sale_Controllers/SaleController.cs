﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Invoicing_System_API.Models.Sale_Model;
using Invoicing_System_API.Models;
using Microsoft.Data.SqlClient;
using System.Data;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.Cors;

namespace Invoicing_System_API.Controllers.Sale_Controllers
{
    [Produces("application/json", "application/xml")]
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("cors")]
    public class SaleController : ControllerBase
    {
        public JXCContextDb db;
        public SaleController(JXCContextDb db) { this.db = db; }
        /// <summary>
        /// 添加订单及订单详情
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        [Route("AddSaleOrdor")]
        [HttpPost]
        public int AddSaleOrdor([FromBody] DataOrdor data)
        {
            SqlParameter[] paras = new SqlParameter[] {
                new SqlParameter(){ParameterName="@SONo",SqlDbType=SqlDbType.NVarChar,Value=data.SONo },
                new SqlParameter(){ParameterName="@UserId",SqlDbType=SqlDbType.Int,Value=data.UserId },
                new SqlParameter(){ParameterName="@CustomerName",SqlDbType=SqlDbType.NVarChar,Value=data.CustomerName },
                new SqlParameter(){ParameterName="@PName",SqlDbType=SqlDbType.NVarChar,Value=data.PName },
                new SqlParameter(){ParameterName="@SinglePrice",SqlDbType=SqlDbType.Decimal,Value=data.SinglePrice },
                new SqlParameter(){ParameterName="@TatolPrice",SqlDbType=SqlDbType.Decimal,Value=data.TatolPrice },
                new SqlParameter(){ParameterName="@AdvPay",SqlDbType=SqlDbType.Decimal,Value=data.AdvPay },
                new SqlParameter(){ParameterName="@DuePay",SqlDbType=SqlDbType.Decimal,Value=data.DuePay },
                new SqlParameter(){ParameterName="@CreateTime",SqlDbType=SqlDbType.DateTime,Value=data.CreateTime },
                new SqlParameter(){ParameterName="@ProNum",SqlDbType=SqlDbType.Int,Value=data.ProNum },
                new SqlParameter(){ParameterName="@result",SqlDbType=SqlDbType.Int,Direction=ParameterDirection.Output }
            };
            using (SqlConnection conn = new SqlConnection("server=.;database=PSS;uid=sa;pwd=123"))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("AddSaleOrdor", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddRange(paras);
                    cmd.ExecuteNonQuery();
                    int i = Convert.ToInt32(paras[paras.Length - 1].Value);
                    conn.Close();
                    return i;
                }
            }
        }
        /// <summary>
        /// 根据登录的销售人员显示其对应的订单
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        [Route("GetSaleOrdor")]
        [HttpGet]
        public OrdorPageData GetSaleOrdor(int userId, int pageIndex = 1,int pageSize = 5, string sono = "",string cusName="")
        {
            var list = from o in db.SaleOrderInfo
                       where o.UserId == userId
                       select o;
            if (!string.IsNullOrEmpty(sono))
            {
                list = list.Where(m => m.SONo.Contains(sono));
            }
            if (!string.IsNullOrEmpty(cusName))
            {
                list = list.Where(m => m.CustomerName.Contains(cusName));
            }
            if (pageIndex < 1)
            {
                pageIndex = 1;
            }
            int count;
            if (list.Count() > 0 && list.Count() % pageSize == 0)
            {
                count = list.Count() / pageSize;
            }
            else
            {
                count = list.Count() / pageSize + 1;
            }
            if (pageIndex > count)
            {
                pageIndex = count;
            }
            OrdorPageData pd = new OrdorPageData();
            pd.list = list.Skip((pageIndex - 1) * pageSize)
                          .Take(pageSize)
                          .ToList();
            pd.totalCount = list.Count();
            pd.totalPage = count;
            pd.currentPage = pageIndex;
            return pd;
        }
        [Route("BindStatus")]
        [HttpGet]
        public async Task<ActionResult<IEnumerable<OrdorStatus>>> BindStatus()
        {
            return await db.OrdorStatus.ToListAsync();
        }
        /// <summary>
        /// 销售订单详情
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        [Route("GetSaleOrdorList")]
        [HttpPost]
        public  PageData GetSaleOrdorList(int userId,int pageIndex=1,int pageSize=5, string sono="",string startTime="",string endTime="",int status=0)
        {
            var list=from o in db.SaleOrderInfo
                     join s in db.SaleListInfo on o.SOId equals s.SOId
                     join ta in db.OrdorStatus on s.OrdorStatus equals ta.SId
                     where o.UserId == userId
                     select new DataOrdor { SO_Id = s.SO_Id, SOId = o.SOId, ProNum = s.ProNum, PName = o.PName, SinglePrice = s.SinglePrice, TatolPrice = s.TatolPrice, CreateTime = s.CreateTime.ToString("yyyy-MM-dd"), AdvPay = s.AdvPay, DuePay = s.DuePay, SONo = o.SONo, CustomerName = o.CustomerName, UserId = o.UserId,SId=ta.SId,SName=ta.SName };
            if (!string.IsNullOrEmpty(sono))
            {
                list = list.Where(m => m.SONo.Contains(sono));
            }
            if (!string.IsNullOrEmpty(startTime))
            {
                list = list.Where(m => Convert.ToDateTime(m.CreateTime) == Convert.ToDateTime(startTime));
            }
            if (!string.IsNullOrEmpty(endTime))
            {
                list = list.Where(m => Convert.ToDateTime(m.CreateTime) <= Convert.ToDateTime(endTime));
            }
            if (status != 0)
            {
                list = list.Where(m => m.SId == status);
            }
            if (pageIndex < 1)
            {
                pageIndex = 1;
            }
            int count;
            if (list.Count() > 0 && list.Count() % pageSize == 0)
            {
                count = list.Count() / pageSize;
            }
            else
            {
                count = list.Count() / pageSize + 1;
            }
            if (pageIndex > count)
            {
                pageIndex = count;
            }
            PageData pd = new PageData();
            pd.list = list.Skip((pageIndex - 1) * pageSize)
                          .Take(pageSize)
                          .ToList();
            pd.totalCount = list.Count();
            pd.totalPage = count;
            pd.currentPage = pageIndex;
            return pd;
        }
        /// <summary>
        /// 审批
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Route("UptStatus")]
        [HttpPut]
        public async Task<ActionResult<int>> UptStatus(int id,string type)
        {
            SaleListInfo sale = db.SaleListInfo.Find(id);
            if (type.Equals("store"))
            {
                db.Entry(sale).State = EntityState.Modified;
                sale.OrdorStatus = 2;
                var list = from o in db.SaleOrderInfo
                           join s in db.SaleListInfo on o.SOId equals s.SOId
                           where s.SO_Id == id
                           select new OutStoreBill { ProName = o.PName, ProNum = s.ProNum, UserId = o.UserId, SONo = o.SONo };
                OutStoreBill bill = list.SingleOrDefault();
                db.outStoreBills.Add(bill);
                return await db.SaveChangesAsync();
            }
            else
            {
                db.Entry(sale).State = EntityState.Modified;
                sale.OrdorStatus = 6;
                return await db.SaveChangesAsync();
            }
        }
        /// <summary>
        /// 删除订单以及对应的订单详情
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [Route("DelOrdorBill")]
        [HttpDelete]
        public async Task<ActionResult<int>> DelOrdorBill(int id)
        {
            var bill=db.SaleListInfo.Find(id);
            SaleListInfo sale = new SaleListInfo();
            sale.SOId = db.SaleListInfo.Where(m => m.SO_Id == id).FirstOrDefault().SOId;
            db.SaleListInfo.Remove(bill);
            var ordor =db.SaleOrderInfo.Find(sale.SOId);
            db.SaleOrderInfo.Remove(ordor);
            return await db.SaveChangesAsync();
        }
    }
}
