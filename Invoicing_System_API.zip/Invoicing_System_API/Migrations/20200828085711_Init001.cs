﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Invoicing_System_API.Migrations
{
    public partial class Init001 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {


            migrationBuilder.CreateTable(
                name: "departments",
                columns: table => new
                {
                    DId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_departments", x => x.DId);
                });

            migrationBuilder.CreateTable(
                name: "juers",
                columns: table => new
                {
                    JID = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Menu = table.Column<string>(nullable: true),
                    FID = table.Column<int>(nullable: false),
                    MenuUrl = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_juers", x => x.JID);
                });

            migrationBuilder.CreateTable(
                name: "rjs",
                columns: table => new
                {
                    UserJ = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    JID = table.Column<int>(nullable: false),
                    RID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_rjs", x => x.UserJ);
                });

            migrationBuilder.CreateTable(
                name: "roleInfos",
                columns: table => new
                {
                    RId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RName = table.Column<string>(nullable: true),
                    UID = table.Column<int>(nullable: false),
                    JID = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_roleInfos", x => x.RId);
                });


            migrationBuilder.CreateTable(
                name: "urs",
                columns: table => new
                {
                    UserRole = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RId = table.Column<int>(nullable: false),
                    UId = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_urs", x => x.UserRole);
                });

            migrationBuilder.CreateTable(
                name: "userInfos",
                columns: table => new
                {
                    UId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserName = table.Column<string>(nullable: true),
                    UserPwd = table.Column<string>(nullable: true),
                    RealName = table.Column<string>(nullable: true),
                    Sex = table.Column<int>(nullable: false),
                    Age = table.Column<int>(nullable: false),
                    TeIphone = table.Column<string>(nullable: true),
                    RoleId = table.Column<int>(nullable: false),
                    DepartId = table.Column<int>(nullable: false),
                    UserState = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_userInfos", x => x.UId);
                });

            migrationBuilder.CreateTable(
                name: "XNjieshou",
                columns: table => new
                {
                    Zid = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AId = table.Column<int>(nullable: false),
                    Proid = table.Column<int>(nullable: false),
                    PId = table.Column<int>(nullable: false),
                    Supplier = table.Column<string>(nullable: true),
                    CreateTime = table.Column<DateTime>(nullable: false),
                    UserId = table.Column<int>(nullable: false),
                    SinglePrice = table.Column<decimal>(nullable: false),
                    TotalPrice = table.Column<decimal>(nullable: false),
                    PRId = table.Column<int>(nullable: false),
                    ProName = table.Column<string>(nullable: true),
                    ProNum = table.Column<int>(nullable: false),
                    StoreId = table.Column<int>(nullable: false),
                    PState = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_XNjieshou", x => x.Zid);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "accept_Goods");

            migrationBuilder.DropTable(
                name: "City");

            migrationBuilder.DropTable(
                name: "departments");

            migrationBuilder.DropTable(
                name: "juers");

            migrationBuilder.DropTable(
                name: "OrdorStatus");

            migrationBuilder.DropTable(
                name: "OutStoreBill");

            migrationBuilder.DropTable(
                name: "Pro");

            migrationBuilder.DropTable(
                name: "pruchaseOderIds");

            migrationBuilder.DropTable(
                name: "PurchaseInfo");

            migrationBuilder.DropTable(
                name: "PurchaseInfoRequest");

            migrationBuilder.DropTable(
                name: "PurchaseRequisition");

            migrationBuilder.DropTable(
                name: "rjs");

            migrationBuilder.DropTable(
                name: "roleInfos");

            migrationBuilder.DropTable(
                name: "SaleListInfo");

            migrationBuilder.DropTable(
                name: "SaleOrderInfo");

            migrationBuilder.DropTable(
                name: "storeGoods");

            migrationBuilder.DropTable(
                name: "StoreInfos");

            migrationBuilder.DropTable(
                name: "urs");

            migrationBuilder.DropTable(
                name: "userInfos");

            migrationBuilder.DropTable(
                name: "XNjieshou");
        }
    }
}
