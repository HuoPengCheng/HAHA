﻿using Invoicing_System_API.Models.Sale_Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.Store_Model.Sale
{
    /// <summary>
    /// 分页
    /// </summary>
    public class OutSaleDataPage
    {
        public List<OutStoreBill> list { get; set; }
        public int TotalPage { get; set; }
    }
}
