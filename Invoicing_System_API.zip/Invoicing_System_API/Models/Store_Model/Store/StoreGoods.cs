﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.Store_Model.Pruchase
{
    /// <summary>
    /// 仓库的商品
    /// </summary>
    public class StoreGoods
    {
        [Key]
        public int SGId { get; set; }
        /// <summary>
        /// 商品名称
        /// </summary>
        public string ProName { get; set; }
        /// <summary>
        /// 商品数量
        /// </summary>
        public int ProNum { get; set; }
        /// <summary>
        /// 仓库外键
        /// </summary>
        public int StoreId { get; set; }
    }
}
