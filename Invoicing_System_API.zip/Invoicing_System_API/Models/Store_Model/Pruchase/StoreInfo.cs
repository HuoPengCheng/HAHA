﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.新文件夹
{
    /// <summary>
    /// 仓库表
    /// </summary>
    public class StoreInfo
    {
        [Key]
        public int SId { get; set; }
        /// <summary>
        /// 仓库名称
        /// </summary>
        public string SName { get; set; }
        /// <summary>
        /// 省级外键
        /// </summary>
        public int ProId { get; set; }
        /// <summary>
        /// 城市外键
        /// </summary>
        public int CityId { get; set; }
        /// <summary>
        /// 地址
        /// </summary>
        public string Address { get; set; }
        /// <summary>
        /// 容量
        /// </summary>
        public int Capacity { get; set; }
    }
}
