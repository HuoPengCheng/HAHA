﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.新文件夹
{
    /// <summary>
    /// 省级表
    /// </summary>
    public class Pro
    {
        [Key]
        public int PId { get; set; }
        public string PName { get; set; }
    }

}
