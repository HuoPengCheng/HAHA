﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.Store_Model.Pruchase
{
    /// <summary>
    /// 商品Id，仓库Id
    /// </summary>
    public class PruchaseOderId
    {
        [Key]
        public int poid { get; set; }
        /// <summary>
        /// 仓库外键
        /// </summary>
        public int storeid { get; set; }
        /// <summary>
        /// 商品外键
        /// </summary>
        public int proid { get; set; }
    }
}
