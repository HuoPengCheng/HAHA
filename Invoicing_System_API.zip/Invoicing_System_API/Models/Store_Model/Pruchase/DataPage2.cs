﻿using Invoicing_System_API.Models.Store_Model.Store;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.Store_Model.Pruchase
{
    public class DataPage2
    {
        public List<StoreAllData> storeAllDatas { get; set; }
        /// <summary>
        /// 总页数
        /// </summary>
        public int TotalPage { get; set; }
    }
}
