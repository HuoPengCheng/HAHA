﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.Store_Model
{
    /// <summary>
    /// 显示采购所有信息
    /// </summary>
    public class PruchaseAllList
    {
        public int CId { get; set; }
        public int PId { get; set; }
        public int PRId { get; set; }
        public string CName { get; set; }
        public string PName { get; set; }
        /// <summary>
        /// 商品名称
        /// </summary>
        public string ProName { get; set; }
        /// <summary>
        /// 商品数量
        /// </summary>
        public int ProNum { get; set; }
        /// <summary>
        /// 仓库名称
        /// </summary>
        public string SName { get; set; }

        /// <summary>
        /// 地址
        /// </summary>
        public string Address { get; set; }
        /// <summary>
        /// 容量
        /// </summary>
        public int Capacity { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public int PState { get; set; }
        /// <summary>
        /// 供应商
        /// </summary>
        public string Supplier { get; set; }
        /// <summary>
        /// 创建日期
        /// </summary>
        public string CreateTime { get; set; }
        /// <summary>
        /// 用户外键
        /// </summary>
        public int UserId { get; set; }
        /// <summary>
        /// 单价
        /// </summary>
        public decimal SinglePrice { get; set; }
        /// <summary>
        /// 总价
        /// </summary>
        public decimal TotalPrice { get; set; }
    }
}
