﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.新文件夹
{
    /// <summary>
    /// 采购仓库
    /// </summary>
    public class PurchaseRequisition
    {
        [Key]
        public int PRId { get; set; }
        /// <summary>
        /// 商品名称
        /// </summary>
        public string ProName { get; set; }
        /// <summary>
        /// 商品数量
        /// </summary>
        public int ProNum { get; set; }
        /// <summary>
        /// 仓库外键
        /// </summary>
        public int StoreId { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public int PState { get; set; }
    }
}
