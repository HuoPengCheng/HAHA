﻿using Invoicing_System_API.Models.Store_Model.Store;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.Store_Model
{
    /// <summary>
    /// 分页Model
    /// </summary>
    public class DataPage
    {
        /// <summary>
        /// 显示表
        /// </summary>
        public List<PruchaseAllList> PruchaseAllLists { get; set; }
        /// <summary>
        /// 总页数
        /// </summary>
        public int TotalPage { get; set; }
    }
}
