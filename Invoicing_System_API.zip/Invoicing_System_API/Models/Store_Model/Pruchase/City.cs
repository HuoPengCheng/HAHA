﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models
{
    /// <summary>
    /// 城市表
    /// </summary>
    public class City
    {
        [Key]
        public int CId { get; set; }
        public string CName { get; set; }
        /// <summary>
        /// 省级外键
        /// </summary>
        public int Pid { get; set; }
    }
}
