﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.pruchase_Model
{
    public class PageViewModel
    {
        public List<PurchaseInfo> PurchaseInfoS { get; set; }

        public List<XNjieshou> XNjieshouS { get; set; }
        /// <summary>
        /// 当前页
        /// </summary>
        public int pageIndex { get; set; }
        /// <summary>
        /// 多少页
        /// </summary>
        public int PageTotal { get; set; }

    }
}
