﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.pruchase_Model
{
    public class Accept_Goods
    {
        /// <summary>
        /// 接受商品表
        /// </summary>
        [Key]
        //主键
        public int AId { get; set; }
        //申请来的商品外键
        public int Proid { get; set; }
    }
}
