﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.pruchase_Model
{
    /// <summary>
    /// 采购表（请求）
    /// </summary>
    public class PurchaseInfoRequest
    {
        [Key]
        public int PId { get; set; }
        /// <summary>
        /// 请购表外键
        /// </summary>
        public int Proid { get; set; }
        /// <summary>
        /// 供应商
        /// </summary>
        public string Supplier { get; set; }
        /// <summary>
        /// 创建日期
        /// </summary>
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 用户外键
        /// </summary>
        public int UserId { get; set; }
        /// <summary>
        /// 单价
        /// </summary>
        public decimal SinglePrice { get; set; }
        /// <summary>
        /// 总价
        /// </summary>
        public decimal TotalPrice { get; set; }
    }
}
