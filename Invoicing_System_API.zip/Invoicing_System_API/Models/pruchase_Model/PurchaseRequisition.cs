﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.pruchase_Model
{

    public class PurchaseRequisition
    {
        [Key]
        public int PRId { get; set; }
        public string ProName { get; set; }
        public int ProNum { get; set; }
        public int PState { get; set; }
        public int StoreId { get; set; }
    }

}
