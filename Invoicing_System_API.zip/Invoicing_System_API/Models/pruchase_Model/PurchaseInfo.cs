﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.pruchase_Model
{
    /// <summary>
    /// 采购（主动）
    /// </summary>
    public class PurchaseInfo
    {
        [Key]
        public int LId { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public int LState { get; set; }
        /// <summary>
        /// 商品名称
        /// </summary>
        public string ProName { get; set; }
        /// <summary>
        /// 供应商
        /// </summary>
        public string LSupplier { get; set; }
        /// <summary>
        /// 创建日期
        /// </summary>
        public DateTime LCreateTime { get; set; }
        /// <summary>
        /// 用户外键
        /// </summary>
        public int LUserId { get; set; }
        /// <summary>
        /// 单价
        /// </summary>
        public decimal LSinglePrice { get; set; }
        ///
        /// 数量
        /// 
        public int Lnumber { get; set; }
        /// <summary>
        /// 总价
        /// </summary>
        public decimal LTotalPrice { get; set; }
    }
}
