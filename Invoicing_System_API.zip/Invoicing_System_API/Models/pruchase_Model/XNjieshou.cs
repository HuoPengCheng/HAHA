﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.pruchase_Model
{
    public class XNjieshou
    {
        [Key]
        public int Zid { get; set; }
        public int AId { get; set; }
        //申请来的商品外键
        public int Proid { get; set; }
        public int PId { get; set; }
        /// <summary>
        /// 供应商
        /// </summary>
        public string Supplier { get; set; }
        /// <summary>
        /// 创建日期
        /// </summary>
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 用户外键
        /// </summary>
        public int UserId { get; set; }
        /// <summary>
        /// 单价
        /// </summary>
        public decimal SinglePrice { get; set; }
        /// <summary>
        /// 总价
        /// </summary>
        public decimal TotalPrice { get; set; }
        public int PRId { get; set; }
        public string ProName { get; set; }
        public int ProNum { get; set; }
        public int StoreId { get; set; }
        public int PState { get; set; }
    }
}
