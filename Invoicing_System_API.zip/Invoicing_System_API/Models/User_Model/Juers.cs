﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.User_Model
{
    //菜单表
    public class Juers
    {
        [Key]
        public int JID { get; set; } //菜单主键
        public string Menu { get; set; } //菜单
        public int FID { get; set; } //父级ID
        public string MenuUrl { get; set; }//路径


    }
}
