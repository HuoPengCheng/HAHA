﻿using Microsoft.AspNetCore.Mvc.ApplicationModels;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Store_Management_MVC.Models.User_Model
{
    //角色表
    public class RoleInfos
    {
        [Key]
        public int RId { get; set; }//主键
        public string RName { get; set; }//角色名称
    }
}
