﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.User_Model
{
    public class Urs //用户角色表
    {
        [Key]
        public int UserRole { get; set; } //主键
        public int RId { get; set; } //角色外键
        public int UId { get; set; } //用户外键

    }
}
