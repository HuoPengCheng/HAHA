﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.User_Model
{
    public class Rjs //角色菜单表
    {
        [Key]
        public int UserJ { get; set; }  //主键
        public int JID { get; set; }//菜单外键
        public int RID { get; set; } // 角色外键
    }
}
