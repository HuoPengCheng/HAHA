﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.User_Model.虚拟表
{
    public class Rjs
    {
        [Key]
        public int UserJ { get; set; }  //主键
        public int JID { get; set; }//权限外键
        public int RID { get; set; } // 角色外键
    }
}
