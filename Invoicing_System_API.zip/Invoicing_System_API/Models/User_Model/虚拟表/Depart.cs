﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.User_Model.虚拟表
{
    public class Depart
    {
        public int DId { get; set; } //主键
        public string DName { get; set; } //部门名称
    }
}
