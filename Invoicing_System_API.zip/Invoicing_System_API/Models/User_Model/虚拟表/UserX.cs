﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.User_Model
{
    public class UserX
    {
        [Key]
        public int UId { get; set; }
        public string UserName { get; set; }
        public string UserPwd { get; set; }
        public string RealName { get; set; }
        public int Sex { get; set; }
        public int Age { get; set; }
        public string TeIphone { get; set; }
        public int RoleId { get; set; }
        public int DepartId { get; set; }
        public string aa { get; set; } //部门名称
        public string b { get; set; }//角色名称
        public int UserState { get; set; }
    }
}
