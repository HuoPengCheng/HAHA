﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.User_Model.虚拟表
{
    public class Role
    {
        public int RId { get; set; }//主键
        public string RName { get; set; }//角色名称
        public int UID { get; set; }//用户外键
        public int jID { get; set; } //权限外键
    }
}
