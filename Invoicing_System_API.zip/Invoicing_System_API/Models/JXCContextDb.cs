﻿using Invoicing_System_API.Models.Store_Model.Pruchase;
using Invoicing_System_API.Models.新文件夹;
using Microsoft.EntityFrameworkCore;
using Invoicing_System_API.Models.Sale_Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Invoicing_System_API.Models.pruchase_Model;
using Store_Management_MVC.Models.User_Model;
using Invoicing_System_API.Models.User_Model;
using Store_Management_MVC.Models;

namespace Invoicing_System_API.Models
{
    public class JXCContextDb:DbContext
    {
        public JXCContextDb() { }
        public JXCContextDb(DbContextOptions<JXCContextDb> options) : base(options) { }

        //仓库管理表
        public DbSet<City> City { get; set; }
        public DbSet<Pro> Pro { get; set; }
        public DbSet<pruchase_Model.PurchaseRequisition> PurchaseRequisition { get; set; }
        public DbSet<StoreGoods> storeGoods { get; set; }
        public DbSet<StoreInfo> StoreInfos { get; set; }
        public DbSet<PruchaseOderId> pruchaseOderIds { get; set; }
        //销售管理
        public DbSet<OrdorStatus> OrdorStatus { get; set; }
        public DbSet<SaleOrderInfo> SaleOrderInfo { get; set; }
        public DbSet<SaleListInfo> SaleListInfo { get; set; }
        public DbSet<OutStoreBill> outStoreBills { get; set; }
        //采购管理
        public DbSet<PurchaseInfo> PurchaseInfo { get; set; }
        public DbSet<PurchaseInfoRequest> PurchaseInfoRequest { get; set; }

        public DbSet<Accept_Goods> accept_Goods { get; set; }

        public DbSet<XNjieshou> XNjieshou { get; set; }

        //系统管理
        public DbSet<Department> departments { get; set; }

        public DbSet<Juers> juers { get; set; }

        public DbSet<Rjs> rjs { get; set; }

        public DbSet<RoleInfos> roleInfos { get; set; }

        public DbSet<Urs> urs { get; set; }

        public DbSet<UserInfos> userInfos { get; set; }

    }
}
