﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.Sale_Model
{
    [Table("SaleListInfo")]
    public class SaleListInfo
    {
        /// <summary>
        /// 底单详情表主键
        /// </summary>
        [Key]
        public int SO_Id { get; set; }
        /// <summary>
        /// 外键（订单表）
        /// </summary>
        public int SOId { get; set; }
        /// <summary>
        /// 商品数量
        /// </summary>
        public int ProNum { get; set; }
        /// <summary>
        /// 商品单价
        /// </summary>
        public decimal SinglePrice { get; set; }
        /// <summary>
        /// 订单总金额
        /// </summary>
        public decimal TatolPrice { get; set; }
        /// <summary>
        /// 预付货款
        /// </summary>
        public decimal AdvPay { get; set; }
        /// <summary>
        /// 剩余应收货款
        /// </summary>
        public decimal DuePay { get; set; }
        /// <summary>
        /// 订单创建时间
        /// </summary>
        public DateTime CreateTime { get; set; }
        /// <summary>
        /// 订单状态
        /// </summary>
        public int OrdorStatus { get; set; }
    }
}
