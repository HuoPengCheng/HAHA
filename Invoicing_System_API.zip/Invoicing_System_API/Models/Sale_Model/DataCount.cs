﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.Sale_Model
{
    public class DataCount
    {
        public int billcount { get; set; }
        public int Mon { get; set; }
    }
}
