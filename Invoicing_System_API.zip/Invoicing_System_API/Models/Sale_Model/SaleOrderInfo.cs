﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.Sale_Model
{
    [Table("SaleOrderInfo")]
    public class SaleOrderInfo
    {
        /// <summary>
        /// 销售订单表主键
        /// </summary>
        [Key]
        public int SOId { get; set; }
        /// <summary>
        /// 订单编号
        /// </summary>
        [StringLength(50)]
        public string SONo { get; set; }
        /// <summary>
        /// 外键(销售员)
        /// </summary>
        public int UserId { get; set; }
        /// <summary>
        /// 客户名称
        /// </summary>
        [StringLength(100)]
        public string CustomerName { get; set; }
        /// <summary>
        /// 商品名称
        /// </summary>
        [StringLength(50)]
        public string PName { get; set; }
    }
}

