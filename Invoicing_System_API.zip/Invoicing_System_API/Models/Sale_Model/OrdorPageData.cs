﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.Sale_Model
{
    public class OrdorPageData
    {
        public List<SaleOrderInfo> list { get; set; }
        public int currentPage { get; set; }
        public int totalCount { get; set; }
        public int totalPage { get; set; }
    }
}
