﻿using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.Sale_Model
{
    public class DataOrdor
    {
        public int SO_Id { get; set; }
        /// <summary>
        /// 外键（订单表）
        /// </summary>
        public int SOId { get; set; }
        /// <summary>
        /// 商品数量
        /// </summary>
        public int ProNum { get; set; }
        /// <summary>
        /// 商品单价
        /// </summary>
        public decimal SinglePrice { get; set; }
        /// <summary>
        /// 订单总金额
        /// </summary>
        public decimal TatolPrice { get; set; }
        /// <summary>
        /// 预付货款
        /// </summary>
        public decimal AdvPay { get; set; }
        /// <summary>
        /// 剩余应收货款
        /// </summary>
        public decimal DuePay { get; set; }
        /// <summary>
        /// 订单创建时间
        /// </summary>
        public string CreateTime { get ; set; }
        /// <summary>
        /// 订单状态
        /// </summary>
        public int SId { get; set; }
        /// 订单编号
        /// </summary>
        public string SONo { get; set; }
        /// <summary>
        /// 外键(销售员)
        /// </summary>
        public int UserId { get; set; }
        /// <summary>
        /// 客户名称
        /// </summary>
        public string CustomerName { get; set; }
        /// <summary>
        /// 商品名称
        /// </summary>
        public string PName { get; set; }
        public string SName { get; set; }
    }
}
