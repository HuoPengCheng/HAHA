﻿using Invoicing_System_API.Models.新文件夹;
using Microsoft.AspNetCore.Authorization;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_API.Models.Sale_Model
{
    [Table("OutStoreBill")]
    public class OutStoreBill
    {
        [Key]
        public int OId { get; set; }
        /// <summary>
        /// 商品名称
        /// </summary>
        [StringLength(50)]
        public string ProName { get; set; }
        /// <summary>
        /// 出库商品数量
        /// </summary>
        public int ProNum { get; set; }
        /// <summary>
        /// 销售订单号
        /// </summary>
        public string SONo { get; set; }
        /// <summary>
        /// 销售员
        /// </summary>
        public int UserId { get; set; }
        public int OState { get; set; }
    }
}
