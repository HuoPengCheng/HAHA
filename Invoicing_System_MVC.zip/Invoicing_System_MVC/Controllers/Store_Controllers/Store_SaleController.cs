﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Invoicing_System_MVC.Controllers.Store_Controllers
{
    public class Store_SaleController : Controller
    {
        /// <summary>
        /// 显示销售订单
        /// </summary>
        /// <returns></returns>
        public IActionResult OutSaleIndex()
        {
            return View();
        }
    }
}
