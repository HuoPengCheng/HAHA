﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Invoicing_System_MVC.Controllers.Store_Controllers
{
    public class Store_PurchaseController : Controller
    {
        public IActionResult Default()
        {
            return View();
        }
        //申请采购
        public IActionResult Add_Purchase()
        {
            return View();
        }
        /// <summary>
        /// 显示采购仓库所有列表
        /// </summary>
        /// <returns></returns>
        public IActionResult Index()
        {
            return View();
        }
        /// <summary>
        /// 如果库存不足，反填到添加
        /// </summary>
        /// <param name="oid"></param>
        /// <returns></returns>
        public IActionResult Upt(int oid=0)
        {
            if (oid != 0)
            {
                ViewData["id"] = oid;
            }
            return View();

        }
        /// <summary>
        /// 采购单
        /// </summary>
        /// <param name="oid"></param>
        /// <returns></returns>
        public IActionResult GetPruchaseinfo()
        {
            return View();
        }
        //采购单选择仓库入库
        public IActionResult GetPruchaseinfo_Store(int id)
        {
            ViewBag.ids = id;
            return View();
        }
    }
}
