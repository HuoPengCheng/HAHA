﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ClassLibrary1;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Aspose.Cells;
using Invoicing_System_MVC.Models;
namespace Invoicing_System_MVC.Controllers.Store_Controllers
{
    public class StoreController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Img()
        {
            return View();
        }
        //导出
        public FileResult Dao()
        {
            //通过Http获取数据
            HttpClientHelper http = new HttpClientHelper("http://localhost:64538/api/");
            //反序列化
            var data = http.Get("Store/DaoFile");
            var list = JsonConvert.DeserializeObject<List<Data>>(data);
            License l = new Aspose.Cells.License();
            l.SetLicense(@"C:\Users\11371\Desktop\PSS（进销存）\PSS（进销存）\Invoicing_System_MVC\wwwroot\Aid\License.lic");
            //创建一个excal文件
            Workbook wb = new Workbook();
            //获取第一页的所有单元格
            var cells = wb.Worksheets[0].Cells;
            cells[0, 0].PutValue("仓库名称");
            cells[0, 1].PutValue("仓库容量");
            cells[0, 2].PutValue("商品名称");
            cells[0, 3].PutValue("商品数量");
            for (int i = 1; i < list.Count; i++)
            {
                cells[i, 0].PutValue(list[i].SName);
                cells[i, 1].PutValue(list[i].Capacity);
                cells[i, 2].PutValue(list[i].ProName);
                cells[i, 3].PutValue(list[i].ProNum);
            }
            //保存数据到指定盘符
            wb.Save(@"e:\Zhaobo.xls");
            return File(@"e:\Zhaobo.xls", "application/vnd.ms-excel");
        }
    }
}
