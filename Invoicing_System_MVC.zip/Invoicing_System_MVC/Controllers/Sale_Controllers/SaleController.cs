﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Invoicing_System_MVC.Controllers.Sale_Controllers
{
    public class SaleController : Controller
    {
        public IActionResult AddSaleOrdor()
        {
            return View();
        }
        public IActionResult GetSaleOrdor()
        {
            return View();
        }
        public IActionResult GetSaleListOrdor()
        {
            return View();
        }
        public IActionResult ActionView()
        {
            return View();
        }
        public IActionResult DefaultView()
        {
            return View();
        }
        public IActionResult FirstIndex()
        {
            return View();
        }
    }
}
