﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Invoicing_System_MVC.Controllers.User_Controllers
{

    public class UserAddController : Controller
    {
        public IActionResult ShouIndex(string name) //主页
        {
            @ViewBag.name = name;
            return View();
        }
        public IActionResult Upt()  //(部门管理)
        {
            return View();
        }
        public IActionResult Login() //登录
        {
            return View();
        }

        public IActionResult Department(string name)  //(部门管理) 
        {

            @ViewBag.name = name;
            return View();
        }

        public IActionResult Yuser() //(用户管理) 
        {
            return View();
        }

        public IActionResult Fan(int id) //(用户管理) 
        {
            ViewBag.id = id;
            return View();
        }

        public IActionResult UserState() //(用户管理) 
        {
            return View();
        }

        public IActionResult SystemLog()  //(系统日志)
        {
            return View();
        }

        public IActionResult Time()  //(时间轴)
        {
            return View();
        }

        public IActionResult Ditu()  //(时间轴)
        {
            return View();
        }
    } 

    }
