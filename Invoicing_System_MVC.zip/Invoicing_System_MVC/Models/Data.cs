﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Invoicing_System_MVC.Models
{
    public class Data
    {
        /// <summary>
        /// 仓库名称
        /// </summary>
        public string SName { get; set; }
        /// <summary>
        /// 仓库库存
        /// </summary>
        public int Capacity { get; set; }
        /// <summary>
        /// 商品名称
        /// </summary>
        public string ProName { get; set; }
        /// <summary>
        /// 商品数量
        /// </summary>
        public int ProNum { get; set; }
    }
}
